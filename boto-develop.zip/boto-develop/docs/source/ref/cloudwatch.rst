.. ref-cloudwatch

====================
CloudWatch Reference
====================

boto.ec2.cloudwatch
-------------------

.. automodule:: boto.ec2.cloudwatch
   :members:   
   :undoc-members:

boto.ec2.cloudwatch.datapoint
-----------------------------

.. automodule:: boto.ec2.cloudwatch.datapoint
   :members:   
   :undoc-members:

boto.ec2.cloudwatch.metric
--------------------------

.. automodule:: boto.ec2.cloudwatch.metric
   :members:   
   :undoc-members:

boto.ec2.cloudwatch.alarm
--------------------------

.. automodule:: boto.ec2.cloudwatch.alarm
   :members:   
   :undoc-members:

